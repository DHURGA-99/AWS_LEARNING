CustomPlaform_NodeSampleApp
===========================
This repository contains the source for a Node.js sample that uses 
**express** and **ejs** to display a static web page.

See the Packer template, *custom_platform.json*, for details on the AMI and
scripts that the builder runs as it creates the custom platform.

For further information on custom platforms, see the
[Custom Platforms docs](http://docs.aws.amazon.com/elasticbeanstalk/latest/dg/custom-platforms.html).
