CustomPlatform_TomcatSampleApp
==============================
This repository contains the source for a Tomcat sample that displays a static web page when deployed.
Learn more at
[Custom Platforms](http://docs.aws.amazon.com/elasticbeanstalk/latest/dg/custom-platforms.html).
