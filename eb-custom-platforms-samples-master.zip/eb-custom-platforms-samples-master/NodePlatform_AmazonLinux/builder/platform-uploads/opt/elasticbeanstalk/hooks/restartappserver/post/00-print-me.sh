

echo "[Restarting Application Server]/post - Step 3."
